import { getAndShowSocials } from "../../utils/shared.js";

window.addEventListener("load", () => {
  getAndShowSocials();
});
